var calendarmonths="Januar Februar M\u00e4rz April Mai Juni Juli August September Oktober November Dezember".split(" "),weekdays="Sonntag 
Montag Dienstag Mittwoch Donnerstag Freitag Samstag".split(" "),short_weekdays=["Mo","Di","Mi","Do","Fr"];
function updateTime(){var a=new Date,b=a.getHours(),c=a.getMinutes();10>c&&(c="0"+c);var 
d=a.getUTCFullYear(),h=a.getUTCMonth(),k=a.getDate(),a=a.getUTCDay();document.querySelector("#hours").innerHTML=b;document.querySelector("#minutes").innerHTML=c;document.querySelector("#year").innerHTML=d;document.querySelector("#month").innerHTML=calendarmonths[h];document.querySelector("#weekday").innerHTML=weekdays[a];document.querySelector("#day").innerHTML=k}
function disableSubmitButton(a){a.form.submit();a.disabled=!0;a.innerHTML="Suche ..."}function xhr(a,b,c){var d=new 
XMLHttpRequest;d.open(b,a);d.send(null);d.onreadystatechange=function(){4==d.readyState&&c(d.responseText)}}function 
buildMensaPlan(a){a=(new DOMParser).parseFromString(a,"text/xml").getElementsByTagName("Datum");a=[].slice.call(a);a=a.slice(0,5);for(var 
b=document.querySelector("#mensa"),c=0;c<a.length;c++){var d=buildMensaDay(a[c],short_weekdays[c]);b.appendChild(d)}}
function buildMensaDay(a,b){var 
c=a.getElementsByTagName("menu1")[0],d=a.getElementsByTagName("menud")[0],h=a.getElementsByTagName("menue")[0],k=a.getElementsByTagName("menuv")[0],f=a.innerHTML.substring(0,10),l=Date.parse(f),f=new 
Date(0);f.setUTCSeconds(l/1E3);var l=new Date,g=document.createElement("div");g.className="mensa_day__wrapper";var 
m=document.createElement("div");m.className="mensa_day__title";var 
e=document.createElement("div");e.className="mensa_day";1==datesEqual(l,f)&&(e.className+=
" 
mensa_day--today");e.appendChild(buildMensaMenu(c.textContent));e.appendChild(buildMensaMenu(k.textContent));e.appendChild(buildMensaMenu(h.textContent));e.appendChild(buildMensaMenu(d.textContent));m.innerHTML=b;g.appendChild(m);g.appendChild(e);return 
g}function buildMensaMenu(a){var b=document.createElement("div");b.className="mensa_food";b.innerHTML=a;return b}function 
datesEqual(a,b){return a.getUTCFullYear()==b.getUTCFullYear()&&a.getUTCMonth()==b.getUTCMonth()&&a.getDate()==b.getDate()};
